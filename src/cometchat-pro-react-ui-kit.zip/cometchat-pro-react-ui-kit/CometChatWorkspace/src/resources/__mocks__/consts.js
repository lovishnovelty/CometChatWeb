export const COMETCHAT_CONSTANTS = {
    APP_ID: '2434873961f4ce2',
    REGION: 'us',
    AUTH_KEY: 'c8eb8f3f27a37b9b218e20f36772fd86c79c7e16',
    UID: 'SUPERHERO1'
}